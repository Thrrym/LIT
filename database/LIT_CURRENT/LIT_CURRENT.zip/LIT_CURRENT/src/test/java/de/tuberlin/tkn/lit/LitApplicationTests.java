package de.tuberlin.tkn.lit;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LitApplicationTests {

    @Test
    void contextLoads() {
    }
}
