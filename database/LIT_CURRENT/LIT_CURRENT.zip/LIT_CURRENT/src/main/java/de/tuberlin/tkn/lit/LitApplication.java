package de.tuberlin.tkn.lit;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LitApplication {

	public static void main(String[] args) {
		SpringApplication.run(LitApplication.class, args);
	}

}
