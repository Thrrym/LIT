package de.tuberlin.tkn.lit.model.activitypub.objects;

public class Tombstone {
    private static final String type = "Tombstone";

    public String getType() {
        return type;
    }
}
